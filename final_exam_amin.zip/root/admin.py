from django.contrib import admin
from .models  import Services,Category,PortFolio,Team,Pricing,ContactUs


admin.site.register(Services)
admin.site.register(Category)
admin.site.register(PortFolio)
admin.site.register(Team)
admin.site.register(Pricing)
admin.site.register(ContactUs)