# final_exam_amin
 stat with tak ordak
